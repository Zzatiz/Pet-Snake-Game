package club.westcs.petproject;

public class SnakeRunner {

	public static void main(String[] args) {
		Snake snake = new Snake();

	}

}
